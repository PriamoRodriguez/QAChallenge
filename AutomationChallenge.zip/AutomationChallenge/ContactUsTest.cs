﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;

namespace AutomationChallenge
{
    class ContactUsTest
    {
        protected IWebDriver Driver;
        protected string Url = "http://automationpractice.com/";

        [SetUp]
        public void BeforeTest()
        {
            Driver = new OpenQA.Selenium.Chrome.ChromeDriver(@"C:\Users\pconcepcio\Desktop");
            Driver.Navigate().GoToUrl(Url);
        }

        [Test]

        public void Send_contact_with_email_on_blank()
        {
            PO_Automation automation = new PO_Automation(Driver);
            automation.ClickContactBoton();
            Assert.IsTrue(PO_Automation.ContactIsPresent());
            automation.SelectSubjectHeading();
            automation.FillContactOrderReference("1234");
            automation.FillContactMessage("prueba");
            automation.ClickSendMessage();
            Assert.IsTrue(automation.ContactErrorAlert());
        }

        [Test]
        public void Send_contact_with_Order_on_blank()
        {
            PO_Automation automation = new PO_Automation(Driver);
            automation.ClickContactBoton();
            Assert.IsTrue(PO_Automation.ContactIsPresent());
            automation.SelectSubjectHeading();
            automation.FillContactEmailAddress("prueba@prueba.com");
            automation.FillContactMessage("prueba");
            automation.ClickSendMessage();
            Assert.IsTrue(automation.ContactErrorAlert());
        }

        [Test]
        public void Send_contact_with_invalid_email()
        {
            PO_Automation automation = new PO_Automation(Driver);
            automation.ClickContactBoton();
            Assert.IsTrue(PO_Automation.ContactIsPresent());
            automation.SelectSubjectHeading();
            automation.FillContactEmailAddress("prueba");
            automation.FillContactOrderReference("1234");
            automation.FillContactMessage("prueba");
            automation.ClickSendMessage();
            Assert.IsTrue(automation.ContactErrorAlert());
        }

        [Test]
        public void Send_contact_specialchar_order_reference()
        {
            PO_Automation automation = new PO_Automation(Driver);
            automation.ClickContactBoton();
            Assert.IsTrue(PO_Automation.ContactIsPresent());
            automation.SelectSubjectHeading();
            automation.FillContactEmailAddress("prueba@prueba.com");
            automation.FillContactOrderReference("$%##^&");
            automation.FillContactMessage("prueba");
            automation.ClickSendMessage();
            Assert.IsTrue(automation.ContactErrorAlert());
        }



        [TearDown]
        public void AfterTest()
        {
            if (Driver != null)
            {
                Driver.Quit();
            }
        }
    }
}
