﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace AutomationChallenge
{
    class ShoppingCartTest
    {
        [TestFixture]
        class SearchTest
        {
            protected IWebDriver Driver;
            protected string Url = "http://automationpractice.com/";

            [SetUp]
            public void BeforeTest()
            {
                Driver = new ChromeDriver(@"C:\Users\pconcepcio\Desktop");
                Driver.Navigate().GoToUrl(Url);
            }

            [Test]

            public void Add_a_product_to_chart()
            {
                var numberOfItemsToAdd = 1;
                PO_Automation automation = new PO_Automation(Driver);
                automation.AddtoCart();
                Assert.True(automation.CheckNumberOfItemsInCart(numberOfItemsToAdd));
            }

            [Test]

            public void Remove_Item_to_the_chart()
            {
                PO_Automation automation = new PO_Automation(Driver);
                automation.RmvItemFromCart();
                Assert.False(automation.IsCarEmpty());
            }

            [Test]

            public void Proceed_to_checkout_from_the_header()
            {
                PO_Automation automation = new PO_Automation(Driver);
                automation.CheckOut();
                Assert.True(automation.HereonCheckoutPage());
            }


            [TearDown]
            public void AfterTest()
            {
                if (Driver != null)
                {
                    Driver.Quit();
                }
            }
        }

    }
}
