﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace AutomationChallenge
{
    [TestFixture]
    class SearchTest
    {
        protected IWebDriver Driver;
        protected string Url = "http://automationpractice.com/";

        [SetUp]
        public void BeforeTest()
        {
            Driver = new ChromeDriver(@"C:\Users\pconcepcio\Desktop");
            Driver.Navigate().GoToUrl(Url);
        }

        [Test]

        public void Search_title_with_keyword()
        {
            var Item = "dress";
            var ItemName = "Printed Dress";
            PO_Automation automation = new PO_Automation(Driver);
            automation.SearchItem(Item);
            Assert.IsTrue(automation.SearchResult(ItemName));

        }

        [Test]

        public void Search_title_without_keyword()
        {
            var Item = "dress";
            var ItemName = "t-shirt";
            PO_Automation automation = new PO_Automation(Driver);
            automation.SearchItem(Item);
            automation.SearchItem(Item);
            Assert.IsTrue(automation.SearchResult(ItemName));
        }

        [TearDown]
        public void AfterTest()
        {
            if (Driver != null)
            {
                Driver.Quit();
            }
        }
    }
}
