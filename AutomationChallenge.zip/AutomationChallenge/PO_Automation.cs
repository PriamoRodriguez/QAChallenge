using NUnit.Framework;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Diagnostics;

namespace AutomationChallenge
{
    class PO_Automation
    {
        //Selenium WebDriver
        static protected IWebDriver Driver;

        public PO_Automation(IWebDriver driver)
        {
            Driver = driver;
        }


        //Search locators
        static protected By SearchBox = By.Id("search_query_top");
        static protected By SearchBoton = By.Name("submit_search");
        static protected By ItemName = By.ClassName("product-name");

        //ContactForm locators
        static protected By ContactFormBoton = By.XPath("/html/body/div/div[1]/header/div[2]/div/div/nav/div[2]/a");
        static protected By TitlePageContact = By.XPath("/html/body/div/div[2]/div/div[3]/div/h1");
        static protected By SucessfullAlert = By.XPath("/html/body/div/div[2]/div/div[3]/div/p");
        private IWebElement ErrorAlert => Driver.FindElement(By.XPath("/html/body/div/div[2]/div/div[3]/div/div"));
        static protected By ContactEmailBox = By.Id("email");
        private IWebElement ContactSelectSubject => Driver.FindElement(By.Id("id_contact"));
        static protected By ContactOrderBox = By.Id("id_order");
        static protected By ContactSelectFile = By.Id("fileUpload");
        static protected By ContactMessage = By.Id("message");
        static protected By ContactSendMessage = By.Id("submitMessage");

        //Shopping cart locators
        private IWebElement AddBotonIWeb => Driver.FindElement(By.XPath("/html/body/div/div[2]/div/div[2]/div/div[1]/ul[1]/li[1]/div/div[2]/div[2]/a[1]/span"));
        static protected By ContinueShop = By.XPath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span");
        static protected By AddBoton = By.XPath("/html/body/div/div[2]/div/div[2]/div/div[1]/ul[1]/li[1]/div/div[2]/div[2]/a[1]/span");
        private IWebElement HeadCartIWeb => Driver.FindElement(By.XPath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a/b"));
        static protected By HeadCart = By.XPath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a/b");
        private IWebElement shoppingCart => Driver.FindElement(By.ClassName("shopping_cart"));

        //Click to search boton 
        public void SearchItem(string ItemName)
        {
            Driver.FindElement(SearchBox).SendKeys(ItemName);
            Driver.FindElement(SearchBoton).Click();
        }

        //Search result class
        public bool SearchResult(string ItemProduct)
        {
            var products = Driver.FindElements(By.ClassName("product-name"));
            return products.Any(x => x.Text.ToLower().Equals(ItemProduct.ToLower()));
        }

        //Go to Conctact Us form
        public void ClickContactBoton()
        {
            Driver.FindElement(ContactFormBoton).Click();
        }

        //verify if Conctact form is present
        public static bool ContactIsPresent()
        {
            return WaitHandler.ElementIsPresent(Driver, TitlePageContact);
        }

        //Class for select subject
        public void SelectSubjectHeading()
        {

            var selectElement = new SelectElement(ContactSelectSubject);
            selectElement.SelectByText("Customer service");
        }

        //Class for fill Email field
        public void FillContactEmailAddress(string AnyEmail)
        {
            Driver.FindElement(ContactEmailBox).SendKeys(AnyEmail);
        }

        //Class for fill Order Fild
        public void FillContactOrderReference(string AnyOrder)
        {
            Driver.FindElement(ContactOrderBox).SendKeys(AnyOrder);
        }

        //Class for attach a File
        public void ContactAttachFile(string Path)
        {
            Driver.FindElement(ContactSelectFile).SendKeys(Path);
        }

        //Class for fill Message field
        public void FillContactMessage(string AnyMessage)
        {
            Driver.FindElement(ContactMessage).SendKeys(AnyMessage);
        }

        //Class for send the messaage
        public void ClickSendMessage()
        {
            Driver.FindElement(ContactSendMessage).Click();
        }

        //class to avoid throwing an exception
        public bool ContactErrorAlert()
        {
            try
            {
                return ErrorAlert.Displayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        //Class for use the scroll
        private void ScrollToElement(IWebElement element)
        {
            var js = (IJavaScriptExecutor)Driver;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }

       //Class for Add to Cart
        public void AddtoCart()
        {
            ScrollToElement(AddBotonIWeb);
            Wait(3,3);
            Driver.FindElement(AddBoton).Click();
            Wait(3, 3);
            Driver.FindElement(ContinueShop).Click();
        }

        //Class for revome from the Cart
        public void RmvItemFromCart()
        {
            AddtoCart();
            ScrollToElement(HeadCartIWeb);
            Driver.FindElement(HeadCart).Click();

        }

        //class to proceed to checkOut
        public void CheckOut()
        {
            ScrollToElement(HeadCartIWeb);
            ExpandCart();
            Driver.FindElement(By.Id("button_order_cart")).Click();
       
        }

        //Class used for to produce a wait
        public void Wait(double delay, double interval)
        {
            var now = DateTime.Now;
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(delay));
            wait.PollingInterval = TimeSpan.FromSeconds(interval);
            wait.Until(wd => (DateTime.Now - now) - TimeSpan.FromSeconds(delay) > TimeSpan.Zero);
        }

        // Class used to expand the cart section
        private void ExpandCart()
        {
            var element = Driver.FindElement(By.XPath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/div"));
            var js = (IJavaScriptExecutor)Driver;
            js.ExecuteScript("arguments[0].style='display: block;'", element);
        }

        //Class to identify if the car is empty
        public bool IsCarEmpty()
        {
            return shoppingCart.FindElements(By.ClassName("ajax_cart_no_product")).First().GetAttribute("style").Equals("display: inline-block;");
        }

        //Class used to identify the Number of item in the cart
        public bool CheckNumberOfItemsInCart(int items)
        {
            ExpandCart();
            return shoppingCart.FindElement(By.ClassName("ajax_cart_quantity")).Text.Equals(items.ToString());
        }

        //Class used for identify if the checkout page is present
        public bool HereonCheckoutPage()
        {
            Debug.WriteLine(Driver.FindElement(By.Id("cart_title")).Text);
            var result = Driver.FindElement(By.Id("cart_title")).Text.Trim().Contains("SHOPPING-CART SUMMARY");
            Debug.WriteLine(result);
            return result;
        }
        

    }
}